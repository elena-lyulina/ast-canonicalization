class A:
    @staticmethod
    def foo():
        pass

A.foo()
