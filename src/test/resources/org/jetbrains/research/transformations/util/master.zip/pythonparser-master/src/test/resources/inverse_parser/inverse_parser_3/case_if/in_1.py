def foo():
    pass
a = 5
if a > 0:
    foo()