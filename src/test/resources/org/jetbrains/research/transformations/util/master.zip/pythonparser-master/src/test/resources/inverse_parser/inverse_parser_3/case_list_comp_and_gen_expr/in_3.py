a = range(100)
b = (_ ** 2 for _ in a if _ > 5 if _ < 10)
