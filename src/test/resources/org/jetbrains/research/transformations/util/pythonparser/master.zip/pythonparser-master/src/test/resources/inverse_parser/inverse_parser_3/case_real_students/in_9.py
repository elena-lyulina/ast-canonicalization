a = int(input())
b = int(input())
c = int(input())
if a > b:
    if a > b:
        print(a)
if b > c:
    print(b)
else:
    print(c)
