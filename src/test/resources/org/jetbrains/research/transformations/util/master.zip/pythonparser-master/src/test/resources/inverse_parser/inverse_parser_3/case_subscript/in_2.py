a = "lalala"
b = a[1]