class A:
    pass


class B:
    pass