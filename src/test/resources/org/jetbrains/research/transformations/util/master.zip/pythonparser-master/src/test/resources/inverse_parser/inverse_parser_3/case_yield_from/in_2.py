def iterable2():
    yield from [1, 2, 3]
    yield 3