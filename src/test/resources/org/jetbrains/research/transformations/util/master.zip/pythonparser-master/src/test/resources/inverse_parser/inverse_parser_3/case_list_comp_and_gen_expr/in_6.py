a = [_ for _ in range(10)]
