s = input()
mm = 0
for i in s:
    mm = max(mm, int(i))
print(mm)
