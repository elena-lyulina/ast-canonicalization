def foo():
    Ellipsis