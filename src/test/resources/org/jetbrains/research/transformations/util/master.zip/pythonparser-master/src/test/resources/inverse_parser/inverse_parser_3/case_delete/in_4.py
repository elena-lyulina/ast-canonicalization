a = {'a': 5, 'b': 4}
del a['a']