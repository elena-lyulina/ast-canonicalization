@all
class A(object,metaclass=StopIteration):
    pass