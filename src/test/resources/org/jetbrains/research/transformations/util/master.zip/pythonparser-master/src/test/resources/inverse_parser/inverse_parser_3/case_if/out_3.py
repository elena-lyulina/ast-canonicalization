def foo():
    pass


def foo_2():
    pass


def foo_3():
    pass


a = 5
if a > 0:
    foo()
elif a == 0:
    foo_2()
elif a == -1:
    foo_3()