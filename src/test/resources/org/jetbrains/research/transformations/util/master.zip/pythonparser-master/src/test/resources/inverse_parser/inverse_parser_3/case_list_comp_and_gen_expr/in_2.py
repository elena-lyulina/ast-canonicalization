lines = 'line_1\nline_2\nline_3'
[ord(c) for line in lines for c in line]