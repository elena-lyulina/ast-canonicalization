boolean = True
byte_val = b'some expr'
string = "asdada"

