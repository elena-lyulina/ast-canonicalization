a = [5, 4, 3]
del a