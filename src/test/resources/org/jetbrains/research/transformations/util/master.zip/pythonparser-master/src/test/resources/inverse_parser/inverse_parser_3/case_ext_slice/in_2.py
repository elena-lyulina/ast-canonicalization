a = [range(100)]
b = a[::]