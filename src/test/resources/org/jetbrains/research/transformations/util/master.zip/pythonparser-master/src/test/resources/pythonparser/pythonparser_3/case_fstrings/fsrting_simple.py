# Copyright (c) Aniskov N.

print(f"{1}")
