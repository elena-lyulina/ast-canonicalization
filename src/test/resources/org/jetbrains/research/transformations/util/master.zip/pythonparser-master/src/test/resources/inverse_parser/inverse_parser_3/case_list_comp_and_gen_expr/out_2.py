lines = """line_1
line_2
line_3"""
[ord(c) for line in lines for c in line]