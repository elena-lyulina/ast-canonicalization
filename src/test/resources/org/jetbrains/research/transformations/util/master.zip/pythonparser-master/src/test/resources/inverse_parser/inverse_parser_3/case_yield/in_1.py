def foo():
    l = range(3)
    for i in l:
        yield i * i
