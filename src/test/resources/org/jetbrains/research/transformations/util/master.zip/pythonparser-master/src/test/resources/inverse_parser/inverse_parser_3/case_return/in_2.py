def foo():
    a = 5
    return a