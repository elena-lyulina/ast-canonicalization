def g():
    pass


async def f():
    await g()
    