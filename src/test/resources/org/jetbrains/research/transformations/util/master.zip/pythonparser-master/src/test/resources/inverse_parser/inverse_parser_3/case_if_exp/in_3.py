b = 2
c = 3
d = 4
a = 1 if c > 0 or d % 2 == 0 else d - 4