bb = bytes('test', encoding='UTF-8')
