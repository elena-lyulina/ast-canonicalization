bb = bytes(5)
