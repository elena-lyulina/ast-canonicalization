b = 2
c = 3
d = 4
a = b if c else d