a = 5
del a