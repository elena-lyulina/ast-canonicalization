a = [range(100)]
b = a[1:4:2]