lines = """line_1
line_2
line_3"""
[ord(_) for line in lines for _ in line]