def f():
    pass