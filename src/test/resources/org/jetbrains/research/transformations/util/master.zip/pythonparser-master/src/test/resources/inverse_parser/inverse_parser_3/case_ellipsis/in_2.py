a = Ellipsis
