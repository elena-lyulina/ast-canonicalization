with open('file_1', 'r') as f_1, open('file_2', 'r') as f_2:
    pass