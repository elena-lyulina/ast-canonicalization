x = 3.14
a = f"abs(x={x}) = {abs(x)}?"
