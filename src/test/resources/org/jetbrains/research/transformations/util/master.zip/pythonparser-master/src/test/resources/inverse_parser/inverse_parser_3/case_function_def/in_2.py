def f(a, b=None, c=2, *d, e, f=3, **g):
    pass