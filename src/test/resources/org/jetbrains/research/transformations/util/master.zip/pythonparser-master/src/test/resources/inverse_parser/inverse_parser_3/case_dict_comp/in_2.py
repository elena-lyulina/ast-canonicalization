a = {i: j for i, j in zip([1, 2, 3], [4, 5, 6])}
b = {i: j for i, j in zip([1, 2, 3], [4, 5, 6])}
print(a == b)