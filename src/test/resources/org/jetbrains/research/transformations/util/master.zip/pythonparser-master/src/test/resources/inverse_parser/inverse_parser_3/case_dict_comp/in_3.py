a = {i: j for i, j in zip([1, 2, 3], [4, 5, 6])}
b = {'a': 2, 'b': 3}
print(a == b)