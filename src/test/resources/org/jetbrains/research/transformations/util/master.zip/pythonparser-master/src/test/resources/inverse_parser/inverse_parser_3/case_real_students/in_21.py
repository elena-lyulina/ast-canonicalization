def g(a, b, c):
    if (a == 0 and b == 0):
        return 0
    elif (c == 0 and b == 0):
        return 0
    elif (a == 0 and c == 0):
        return 0
    elif (a == 1 and b == 1):
        return 1
    elif (c == 1 and b == 1):
        return 1
    elif (a == 1 and c == 1):
        return 1
