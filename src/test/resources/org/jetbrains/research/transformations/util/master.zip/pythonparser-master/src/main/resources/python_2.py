hello_world_line = "Hello world!"
print hello_world_line