a = 'test'
a *= 3
print(a)