a = True
c = a and 3 or False
d = not a