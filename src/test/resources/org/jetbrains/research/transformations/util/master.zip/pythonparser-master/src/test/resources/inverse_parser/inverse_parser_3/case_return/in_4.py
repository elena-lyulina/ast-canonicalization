def foo(a):
    if a == 1:
        return
    return None