a = 'test'
a += 'test'