# sample comment

import re as REE
e = 15
c = 1, 2
a = b = 1
x, y = c

p, q = x, y

print(x, y, c)

