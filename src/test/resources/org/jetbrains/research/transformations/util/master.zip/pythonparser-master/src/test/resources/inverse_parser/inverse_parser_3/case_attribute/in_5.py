class A:
    def foo(self):
        pass

a = A()
a.foo()
