bb = bytes()
