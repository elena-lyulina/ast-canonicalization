b = [1, 2, 3]
for a in b:
    continue