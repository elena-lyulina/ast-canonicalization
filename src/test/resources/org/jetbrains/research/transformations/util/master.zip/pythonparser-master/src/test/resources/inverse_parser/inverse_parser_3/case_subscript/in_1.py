a = range(1, 100)
b = a[1]