def foo():
    pass


def foo_2():
    pass


a = 5
if a > 0:
    foo()
elif a == 0:
    foo_2()