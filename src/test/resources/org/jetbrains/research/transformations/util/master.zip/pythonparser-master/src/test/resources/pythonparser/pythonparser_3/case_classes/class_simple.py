# Copyright Aniskov N.


class Complex:
    def __init__(self, real_part, imag_part):
        self.r = real_part
        self.i = imag_part
