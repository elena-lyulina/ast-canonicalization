j = 0
for i in [1, 2, 3]:
    j = j + 1
    b = 2 and 1
else:
    j = j + 1000
