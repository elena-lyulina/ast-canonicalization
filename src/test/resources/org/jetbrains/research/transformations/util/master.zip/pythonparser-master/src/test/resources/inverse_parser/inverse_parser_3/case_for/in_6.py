for i in range(100, 5, -2):
    print(str(i))