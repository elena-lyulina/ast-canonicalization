def f(a, b=1, c=2, *d, e, f=3, **g):
    pass