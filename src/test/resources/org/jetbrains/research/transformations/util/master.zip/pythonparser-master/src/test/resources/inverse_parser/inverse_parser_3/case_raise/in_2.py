from audioop import error
raise ValueError('some msg') from error