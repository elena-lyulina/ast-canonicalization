s1 = {1, 2, 3, 4}
s2 = set(range(1, 10))
