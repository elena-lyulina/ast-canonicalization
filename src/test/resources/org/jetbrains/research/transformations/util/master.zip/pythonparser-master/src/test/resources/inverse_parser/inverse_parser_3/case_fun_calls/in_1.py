args = ('hello!', 'world!')
kwargs = {'sep': ' ', 'end': '\n'}
print(*args, **kwargs)
