bb = bytes("test")
