b = [1, 2, 3]
for a in b:
    if a > 5:
        break