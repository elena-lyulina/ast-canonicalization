def iterable1():
    yield 1
    yield 2