lines = 'line_1\nline_2\nline_3'
[ord(_) for line in lines for _ in line]