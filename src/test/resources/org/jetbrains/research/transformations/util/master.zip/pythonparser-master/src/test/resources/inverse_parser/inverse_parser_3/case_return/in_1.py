def foo():
    return 1