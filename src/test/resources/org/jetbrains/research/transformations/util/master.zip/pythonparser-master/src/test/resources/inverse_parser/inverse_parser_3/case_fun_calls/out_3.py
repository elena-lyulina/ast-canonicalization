x = 2
print(x)
y = 3
print(x, y)
