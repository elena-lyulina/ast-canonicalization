while 1 == 1:
    n = int(input())
    c = int(input())
    a = int(input())
    b = int(input())
    if n == 0 or c == 0 or a == 0 or b == 0:
        print("Yes")
    elif n != 0 and c != 0 and a != 0 and b != 0:
        print("No")
