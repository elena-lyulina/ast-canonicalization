# Copyright (c) Aniskov N.


def foo(a, b, /, c, d, *, e, f):
    print(a, b, c, d, e, f)
