# Copyright (c) Aniskov N.

from datetime import date

user = 'Nick'
member_since = date(1999, 5, 17)
print(f'{user=} {member_since=}')
