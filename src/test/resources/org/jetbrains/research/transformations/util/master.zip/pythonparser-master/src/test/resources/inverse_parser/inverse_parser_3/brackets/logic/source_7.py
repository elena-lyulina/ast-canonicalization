print((not True) or True)
