for x in 'banana':
    print(x)