print(max([int(input()) for _ in range(3)]))
