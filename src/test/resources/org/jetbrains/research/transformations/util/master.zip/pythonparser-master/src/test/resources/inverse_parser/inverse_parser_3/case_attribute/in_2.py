a = [1, 2, 3]
b = a.append(4)