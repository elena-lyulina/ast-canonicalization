bb = bytes('test')
