a = 4
b = 'test'
c = 2.5
d = -a