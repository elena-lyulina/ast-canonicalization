a = int(input())
b = int(input())
c = int(input())
if a == b != c or a == b == c:
    if a == 1:
        print(1)
    else:
        print(0)
if a == c != b or a == b == c:
    if a == 1:
        print(1)
    else:
        print(0)
if a == c != b or a == b == c:
    if a == 1:
        print(1)
    else:
        print(0)
