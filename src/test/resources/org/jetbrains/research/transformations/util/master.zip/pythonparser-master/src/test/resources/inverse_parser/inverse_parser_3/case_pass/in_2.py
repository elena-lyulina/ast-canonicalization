def foo():
    pass