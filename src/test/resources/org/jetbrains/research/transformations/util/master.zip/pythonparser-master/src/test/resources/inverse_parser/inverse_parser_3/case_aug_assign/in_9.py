a = 7
a ^= 3
print(a)