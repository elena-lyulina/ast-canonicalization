def foo(n):
    return lambda a: a * n