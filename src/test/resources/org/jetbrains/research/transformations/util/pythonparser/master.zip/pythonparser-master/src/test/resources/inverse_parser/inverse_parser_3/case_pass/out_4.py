class A:

    def foo(self):
        pass
    pass