dig_list = [int(i) for i in input().split()]
if dig_list.count(1) >= 2:
    print("1")
else:
    print("0")
