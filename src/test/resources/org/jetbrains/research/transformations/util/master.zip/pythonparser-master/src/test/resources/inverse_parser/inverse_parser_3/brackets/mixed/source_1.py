a = 15 * 6
b = 30
c = (41 - 16) * 5
print(a * b - 10 * (c + 15))
print(a * b - 10 * (c + 15) > 10)
print(a * b - 10 * (c + 15) == 10)
