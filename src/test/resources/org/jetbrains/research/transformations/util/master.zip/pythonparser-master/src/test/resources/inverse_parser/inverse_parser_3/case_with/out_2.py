import threading
lock = threading.Lock()
with lock:
    pass