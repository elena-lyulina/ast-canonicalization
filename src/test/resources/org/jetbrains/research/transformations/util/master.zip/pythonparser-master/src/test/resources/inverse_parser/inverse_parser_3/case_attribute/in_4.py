class A:
    @classmethod
    def foo(cls):
        pass

A.foo()
