a = [i for i in range(10)]
