a_rubli = 10
b_coins = 15
n_cake = 2
a_coins = a_rubli * 100
print(a_coins)
vsego = (a_coins + b_coins) / n_cake
vrublyah = (a_coins + b_coins) / n_cake // 100
print(vsego)
print(vrublyah)
