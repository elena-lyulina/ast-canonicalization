i = 0
while i > 3:
    i -= -1
    print('hi')
else:
    print('sds')