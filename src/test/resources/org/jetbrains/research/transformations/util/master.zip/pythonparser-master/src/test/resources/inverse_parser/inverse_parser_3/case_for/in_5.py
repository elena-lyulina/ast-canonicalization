for i in range(5, 100, 2):
    print(str(i))