a = True
b = 15 - 16 * 3
c = (b * 2 - 13) / 5
print(c / (b - 3))
print(c / (b - 3) > 15 and a)
print(c / (b - 3) > 15 and (a or False))
