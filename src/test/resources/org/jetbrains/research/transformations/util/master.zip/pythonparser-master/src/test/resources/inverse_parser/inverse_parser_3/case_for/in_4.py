for i in range(5, 100):
    print(str(i))