a = 5
assert a % 2 == 0
