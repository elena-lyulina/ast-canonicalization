if True:
    print(1)
else:
    print(2)