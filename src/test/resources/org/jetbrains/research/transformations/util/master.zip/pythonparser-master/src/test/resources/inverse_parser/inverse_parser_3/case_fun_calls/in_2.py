print('hello!', 'world!', sep=' ', end='\n')
