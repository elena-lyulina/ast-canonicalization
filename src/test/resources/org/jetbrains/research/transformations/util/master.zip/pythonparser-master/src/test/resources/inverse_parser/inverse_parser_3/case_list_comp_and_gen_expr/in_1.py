a = range(100)
b = (n ** 2 for n in a if n > 5 if n < 10)
