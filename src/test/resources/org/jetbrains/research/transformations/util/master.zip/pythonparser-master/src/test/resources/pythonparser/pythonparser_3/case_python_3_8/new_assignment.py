# Copyright (c) Aniskov N.

t = [1, 2, 3]
if (n := len(t)) > 2:
    print("OK")

